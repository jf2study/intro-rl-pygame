This is for the custom Open AI gym environment that will be used with the PyGame.

Open AI has classes that will need to get the environment through the Gym Registry.

When running in Google colab there are known issues with using the images from the pip-module.  Included with this git repo are installation tar files in the directory install_tar.  These will need to be copied to the Google Drive and the notebooks will need to run the untarring and installation of the pip-module.  The image tar will also need to be untarred, but to avoid naming conflicts, this is left to the user to copy the file up and rename the tarred directory and notebook settings.
