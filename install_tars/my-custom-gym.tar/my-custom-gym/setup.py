from setuptools import setup

setup(name='my_custom_gym',
      version='0.0.1',
      install_requires=['gym','numpy','opencv-python','datetime','pillow','pygame']#And any other dependencies required
)

